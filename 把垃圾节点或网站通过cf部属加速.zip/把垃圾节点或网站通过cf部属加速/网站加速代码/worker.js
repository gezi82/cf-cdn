addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request));
});
 
async function handleRequest(request) {
  const url = new URL(request.url);
 
  // 指定目标反向代理的 URL
  const targetUrl = `vmq.rg520.us.kg${url.pathname}`;
 
  // 创建一个新的请求
  const modifiedRequest = new Request(targetUrl, {
    method: request.method,
    headers: request.headers,
    body: request.body,
    redirect: 'follow'
  });
 
  // 获取目标服务器的响应
  let response = await fetch(modifiedRequest);
 
  // 检查响应类型并重写内容
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('text/html') || contentType.includes('text/css') || contentType.includes('application/javascript')) {
    // 将响应内容转为文本
    let text = await response.text();
 
    // 替换内容，按下面的格式对应填上：例如，将 vmq.rg520.us.kg 替换为 /vmq.rg520.us\.kg/g, 'cdn.rg520.us.kg' 这个 cdn.rg520.us.kg 是 CNAME 指向一个优选域名 you.rg520.us.kg 
    text = text.replace(/vmq.rg520.us\.kg/g, 'cdn.rg520.us.kg');
 
    // 返回修改后的响应
    return new Response(text, {
      status: response.status,
      headers: response.headers
    });
  }
 
  // 如果不是需要重写的类型，则直接返回原始响应
  return response;
}