export default {
  async fetch(request) {
    const base = "https://yzf.cfjs.us.kg/public";
    const statusCode = 301;

    const url = new URL(request.url);
    const { pathname, search } = url;

    const destinationURL = `${base}${pathname}${search}`;
    return Response.redirect(destinationURL, statusCode);
  },
};